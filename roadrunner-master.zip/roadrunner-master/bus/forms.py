from django import forms
from bus.models import Stop
from django.contrib.admin import widgets  
from django.forms import ModelForm



