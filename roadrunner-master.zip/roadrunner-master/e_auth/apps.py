from __future__ import unicode_literals

from django.apps import AppConfig


class EAuthConfig(AppConfig):
    name = 'e_auth'
