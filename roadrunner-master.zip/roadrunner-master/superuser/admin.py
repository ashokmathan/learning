from django.contrib import admin
from .models import *

admin.site.register(Validation)
admin.site.register(UserTemp)
admin.site.register(PassRequest)

# Register your models here.
